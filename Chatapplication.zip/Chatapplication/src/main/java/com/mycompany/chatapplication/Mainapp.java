/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapplication;

/**
 *
 * @author One eyed King
 */
import java.util.Scanner;

public class Mainapp {
    public static void main(String[]args){
        
        //Scanner method allows the user to enter thier information
        Scanner input = new Scanner(System.in);
        
        // An object useed for the login class so we call it's methods
        Login login = new Login();{
        
        //Output dislpayed as a heading for user registration
        System.out.println("=== USER REGISTRATION ===");
        
        //Promts user to enter their username
        System.out.println("Enter a username: ");
        String Username = input.nextLine();
        
        //Prompts the user to enter thier password
        System.out.println("Enter a Password: ");
        String password = input.nextLine();
        
        //Promts the user to enter their phone number
        System.out.println("Enter your South African phone number (+27....): ");
        String Phonenumber = input.nextLine();
        
        // Capatures user input for username,password and phoneNumber 
        String response = login.registerUser(Username, password, Phonenumber);
        
        //Dislays the captured user input
        System.out.println(response);
    
        //User login
        System.out.println("\n ===== USER LOGIN =====");
        
        //Promts user to enter their username
        System.out.print("Enter your username");
        String loginUsername = input.nextLine();
        
        //Prompts the user to enter thier password
        System.out.println("Enter your password : ");
        String loginpassword = input.nextLine();
        
        
        //Checks if the details entered by the user match
        boolean loggedIn = login.loginUser(loginUsername, loginpassword);
        
        //Prints or displays the appropriate message 
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }  
        
    }
    
}
